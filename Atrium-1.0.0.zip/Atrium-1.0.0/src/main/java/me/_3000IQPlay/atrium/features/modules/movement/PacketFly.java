package me._3000IQPlay.atrium.features.modules.movement;

import me._3000IQPlay.atrium.features.modules.Module;

public class PacketFly
        extends Module {
    public PacketFly() {
        super("PacketFly", "PacketFly.", Module.Category.MOVEMENT, true, false, false);
    }
}

