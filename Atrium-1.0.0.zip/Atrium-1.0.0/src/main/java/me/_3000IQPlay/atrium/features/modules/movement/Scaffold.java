package me._3000IQPlay.atrium.features.modules.movement;

import me._3000IQPlay.atrium.features.modules.Module;

public class Scaffold
        extends Module {
    public Scaffold() {
        super("Scaffold", "Scaffold.", Module.Category.MOVEMENT, true, false, false);
    }
}

