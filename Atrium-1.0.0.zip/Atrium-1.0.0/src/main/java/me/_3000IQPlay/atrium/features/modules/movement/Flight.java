package me._3000IQPlay.atrium.features.modules.movement;

import me._3000IQPlay.atrium.features.modules.Module;

public class Flight
        extends Module {
    public Flight() {
        super("Flight", "Flight.", Module.Category.MOVEMENT, true, false, false);
    }
}

