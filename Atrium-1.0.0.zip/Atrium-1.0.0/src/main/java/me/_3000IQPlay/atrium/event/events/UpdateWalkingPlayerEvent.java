package me._3000IQPlay.atrium.event.events;

import me._3000IQPlay.atrium.event.EventStage;

public class UpdateWalkingPlayerEvent
        extends EventStage {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}

