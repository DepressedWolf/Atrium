package me._3000IQPlay.atrium.util;

import net.minecraft.client.Minecraft;

public interface Util {
    Minecraft mc = Minecraft.getMinecraft();
}

