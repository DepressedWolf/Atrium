package me._3000IQPlay.atrium.features.modules.movement;

import me._3000IQPlay.atrium.features.modules.Module;

public class Step
        extends Module {
    public Step() {
        super("Step", "Step.", Module.Category.MOVEMENT, true, false, false);
    }
}

